import pickle

# creating a class called Quiz
# the input for the class will come from the load_questions()
class Quiz:
    def __init__(self,qno,question,answer,correct):
        self.qno=qno
        self.question=question
        self.answer=answer
        self.correct=correct
  
# will return if the answer is correct(True) or incorrect(False)  
    def right_wrong(self,user_ans):
        x=user_ans==int(self.correct)
        return x
    
# creating a class called MathQuiz which will mainly define the player and his score    
class MathQuiz:
    def __init__(self,user,health,points):
        self.user=user
        self.score=0         
        self.health=health   # easy=10hp       medium=5hp        hard=3hp
        self.health_lost=0   
        self.points=points   # easy=1pts/ans   medium=2pts/ans   hard=3pts/ans
        self.questions=[]
       
# this function will append the qno, questions, options and answers into self.questions=[] in line25
    def load_questions(self,file_name):
        quiz_file=open(file_name,'r')
        quiz_file.readline()      # title
        qno,question,answer,correct=self.next_block(quiz_file)
        while qno:      # loop will go an as long as there are questions
            j=Quiz(qno,question,answer,correct)
            self.questions.append(j)
            qno,question,answer,correct=self.next_block(quiz_file)

# This function will determine if you got the answer right or wrong and will give points based on difficulty
    def play(self):
        for question in self.questions:
            self.display(question)
            user_ans=0
            while user_ans not in [1,2,3,4]: # only valid options are 1,2,3 or 4
                try:
                    user_ans=int(input('Enter option---> '))
                    if user_ans not in [1,2,3,4]:
                        print('<invalid number>')
                except:
                    print('<invalid value>') # to avoid value errors
                    
            if question.right_wrong(user_ans):
                print('\nCORRECT')
                self.score+=int(self.points)
                print('\nSCORE : ',self.score)
                print('HEALTH : ',self.health*'🖤 ',self.health_lost*'🤍 ')
            else:
                print('\nWRONG')
                self.health-=1
                self.health_lost+=1
                if self.health==0:    # Quiz will stop if player loses all health
                    print(self.health_lost*'🤍 ')
                    print('\n-----------   G A M E    O V E R   -----------')
                    return 0     # to inform main code to not to dump data into the binary file 'score.dat' (line118)
                    break
                print('\nSCORE : ',self.score)
                print('HEALTH : ',self.health*'🖤 ',self.health_lost*'🤍 ')
                         
# will read the next line and is mainly used by next_block()
# will also replace characters which are changed when reading from text file to python
# eg:   π ---file.readline----> Ï€ --- line.replace ----> π
    def next_line(self,file):
        line=file.readline()
        line=line.replace('!','\n')
        line=line.replace('Â°','°')
        line=line.replace('âˆš','√')
        line=line.replace('Ï€','π')
        line=line.replace('Î¸','θ')
        line=line.replace('âˆž','∞')
        line=line.replace('âˆ«','∫')
        line=line.replace('Î£','Σ')
        return line    # returns to next_block()
    
# mainly called in load_questions() to extract data from the quiz file.
    def next_block(self,file):
        qno=self.next_line(file)
        question=self.next_line(file)
        answer=[self.next_line(file) for i in range(4)]   # there are 4 mcq options 
        correct=self.next_line(file)
        return qno,question,answer,correct   # returns to line31 and line35
    
    
# prints the Qno, question and the mcq options           
    def display(self,question):
        print(question.qno)
        print(question.question)
        opt_num=0
        for ans in question.answer:
            opt_num+=1
            print(str(opt_num)+'. '+ans)

# stores the players name and score into a binary file 'scores.dat'
# called if the player finishes the quiz, will not be called if quiz is not completed due to player losing
    def show_score(self):
        print('\n-----QUIZ COMPLETE!-----\n')
        print('YOUR SCORE === ',self.score)
        info=[self.user,self.score]
        print(info)
        f=open('scores.dat','ab')
        pickle.dump(info,f)
        f.close()
     
# main function, inputs player name, creates an quiz, and calls the functions
# takes arguments such as difficulty from player then health and points are assigned based on difficulty chosen
def main(diff,health,points): # (easy,10,1)      (medium,5,2)       (hard,3,3)
    user_name=input('Enter name ---> ')
    quiz=MathQuiz(user_name,health,points)
    quiz.load_questions(diff)
    abc=quiz.play()
    if abc==0:         # gets notified if player lost from line62 and passes the code without saving data and showing score
        pass
    else:
        quiz.show_score()
    menu()
    
def highscore():
            infile=open('scores.dat','rb')
            scores=[]
            try:
              while True:
                p=pickle.load(infile)
                scores.append(p)
           
            except EOFError:
                    pass
            if scores:
                scores.sort(key=lambda x: x[1], reverse=True) #sorts scores in descending order such that highest score is displayed first
                print('\nHIGHSCORES:')
                for name, score in scores:
                    print(name, ':', score)
            else:
                print('No highscores yet')
            infile.close()
            menu()
   
# the menu
def menu():
    print('\npick an option\n1. Play Game\n2. Check HighScores\n3. Quit')  
    while True:
        try:
           opt=int(input('\nEnter an answer---> ')) # input an option
           if opt==1:
              print('\npick a difficuly\n1. Easy\n2. Medium\n3. Hard')
              opt1=0
              while opt1 not in [1,2,3]:
                  try:
                     opt1=int(input('\nEnter option ---> '))    # input a difficulty
                     if opt1==1:
                        main('ezquiz.txt',10,1)    # assigning arguments to the function for easy quiz
                     elif opt1==2:
                        main('medquiz.txt',5,2)       # assigning arguments to the function for medium quiz
                     elif opt1==3:
                        main('hardquiz.txt',3,3)         # assigning arguments to the function for hard quiz
                     else:
                        print('\t<Invalid Option>')
                  except:
                        print('\n<Invalid Value>')
           elif opt==2:
              highscore()
            
           elif opt==3:
               print('\n-----------CODE OVER-----------')
               break
           else:
               print('\n<Number is not in option>')
                
        except:
            print('\n<Invalid Value>')
     
 
 
print('===WELCOME TO===‪‪')
print('======THE=======')
print('===MATHS QUIZ===')
menu()
